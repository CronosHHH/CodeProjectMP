/*
 * Metodología de la Programación
 * Curso 2025/2026
 */

/**
 * @file VectorInt.h
 * @author Silvia Acid Carrillo <acid@decsai.ugr.es>
 * @author Andrés Cano Utrera <acu@decsai.ugr.es>
 * @author Luis Castillo Vidal <L.Castillo@decsai.ugr.es>
 * 
 * Created on 30 de julio de 2025, 9:54
 */

#ifndef VECTORINT_H
#define VECTORINT_H

#include <iostream>
#include <string>

/**
 * @class VectorInt
 * @brief A VectorInt object contains a vector of integer elements. It has
 * a capacity (maximun number of elements that can be stored in the vector)
 * and a size (number of elements the vector currently contains).
 */
class VectorInt {
public:
    
    /**
     * @brief It builds a VectorInt object (vector of integers) with a 
     * size and capacity equal to the provided value (@p size). Each element
     * will be filled with a value equal to 0.
     * @throw std::out_of_range Throws a std::out_of_range exception if
     * @p size < 0
     * @param size The size for the vector of integers in this object. Input
     * parameter
     */
    VectorInt(int size=0);
    
    /**
     * @brief Copy constructor
     * @param orig the VectorInt object used as source for the copy. Input
     * parameter
     */
    VectorInt(const VectorInt &orig);
    
    /**
     * @brief Destructor
     */
    ~VectorInt();
    
    /**
     * @brief Overloading of the assignment operator for VectorInt class
     * Modifier method
     * @param orig the VectorInt object used as source for the assignment. Input
     * parameter
     * @return A reference to this object
     */
    VectorInt &operator=(const VectorInt &orig);
    
    /**
     * @brief Gets the number of elements in the vector of this object
     * Query method
     * @return The number of elements
     */
    int getSize() const;
    
    /**
     * @brief Gets the capacity of the vector in this object
     * Query method
     * @return The capacity of the vector in this object
     */
    int getCapacity() const;
    
    /**
     * @brief Compares the integer vectors of this object and the provided 
     * object, and returns the number of identical elements in both of them. The 
     * comparison is performed in order, element by element, in both vectors.
     * For example, given the following two vectors:
     * 2 1 2 3 5
     * 1 1 2 4 5
     * this method will return 3 (there is a match ​in positions 1, 2 and 4)
     * @throw std::invalid_argument Throws an std::invalid_argument exception 
     * if the sizes of this and the provided object are different
     * Query method
     * @param other A VectorInt object. Input parameter
     * @return The number of identical elements in the vectors of this
     * and the provided object.
     */
    int countIdenticalElements(const VectorInt &other) const;
    
    /**
     * @brief Obtains a string with information about this VectorInt object, 
     * in the following format:
     * - First line, the number of elements in this vector. 
     * - Second line, the elements in this vector, separated by a whitespace. 
     * Take into account that a '\n' should appear after the last element 
     * instead of a whitespace.
     * Query method
     * @return string with information about this VectorInt object
     */
    std::string toString() const;

    /**
     * @brief Gets the Euclidean distance between this and the provided object.
     * The Euclidean distance between two points \f$ P=(p_1, p_2, ... , p_n) \f$ 
     * and \f$ Q=(q_1, q_2, ... , q_n) \f$ in an n-dimensional space \f$ R^n \f$ 
     * is the length of the line segment connecting them, calculated as the 
     * square root of the sum of the squared differences of their components: 
     * \f$ d(P,Q)=\sqrt{ \sum_{i=1}^{n} (p_i-q_i)^{2} } \f$
     * @throw std::invalid_argument Throws an std::invalid_argument exception 
     * if the size of this object and the provided one are not equal
     * @throw std::invalid_argument Throws an std::invalid_argument exception 
     * if the size of the provided object is zero
     * Query method
     * @param other A VectorInt. Input parameter
     * @return The Euclidean distance between this and the provided objects
     */
    double distance(const VectorInt &other) const;
    
    /**
     * @brief Assigns the provided value to all the elements in this vector
     * Modifier method
     * @param value An integer value. Input parameter
     */
    void assign(int value=0);
    
    /**
     * @brief Appends the given integer value at the end (first free position) 
     * of the array of integers in this object. 
     * If the dynamic array of integers was full (its capacity was full), this
     * method automatically reallocates a new array with a capacity equal to 
     * the current capacity plus an extra block of size equal to BLOCK_SIZE.
     * Modifier method
     * @param value the new integer value to be appended. Input parameter
     */
    void append(int value);
    
    /**
     * @brief Removes all the elements in this object, leaving the container 
     * with a size equal to 0. It only need to set the number of elements 
     * (_size field) to zero.
     * Modifier method
     */
    void clear();

    /**
     * @brief Gets a const reference to the integer element at the given 
     * position
     * Query method
     * @param pos position in the VectorInt object. Input parameter
     * @throw std::out_of_range Throws an std::out_of_range exception if the 
     * given position is not valid.
     * @return A const reference to the integer element at the given position
     */
    const int &at(int pos) const;
    
    /**
     * @brief Gets a reference to the integer element at the given position. 
     * Modifier method
     * @param pos position in the VectorInt object. Input parameter
     * @throw std::out_of_range Throws an std::out_of_range exception if the 
     * given position is not valid
     * @return A reference to the integer element at the given position.
     */
    int &at(int pos);

    /**
     * @brief Overloading of the [] operator for VectorInt class
     * Query method
     * @param index index of the element. Input parameter
     * @return A constant reference to the element at position @p index
     */
    const int &operator[](int index) const;
    
    /**
     * @brief Overloading of the [] operator for VectorInt class
     * Modifier method
     * @param index index of the element. Input parameter
     * @return A reference to the element at position @p index
     */
    int &operator[](int index);

    /**
     * @brief Overloads the operator += for the VectorInt class. 
     * It appends to this VectorInt object the given integer value. The
     * new element is put at the end.
     * Take into account, that this method increases the capacity
     * of the internal dynamic array of integers if that array is full.
     * Modifier method
     * @param value The integer value to append to this object. Input parameter
     * @return A reference to this object.
     */
    VectorInt &operator+=(int value);
    
private:
    void liberar();
    void reservar(int capacity);
    void copiar(const VectorInt &orig);
    void reallocar(int newCapacity);

    /**
     * Pointer to a dynamic array of integers
     */
    int* _values;
    
    /**
     * Number of elements contained in the dynamic array _values
     */
    int _size;
    
    /**
     * Maximun number of elements that can be stored in the dynamic array
     * _values
     */
    int _capacity;
    
    /**
     * Size of new memory blocks when resizing the dynamic array _values
     */
    static const int BLOCK_SIZE=20; 

}; // end of class VectorInt

/**
 * @brief Overloading of the stream insertion operator for VectorInt class. 
 * It sends to the output the information about the provided VectorInt
 * object in the following format:
 * - First line, the number of elements in this vector. 
 * - Second line, the elements in the provided vector, separated by a whitespace. 
 * Take into account that a '\n' should appear after the last element 
 * instead of a whitespace. 
 * @param os The output stream to be used. Input/output parameter
 * @param vector The VectorInt object. Input parameter
 * @return os A reference to the output stream
 */
std::ostream &operator<<(std::ostream &os, const VectorInt &vector);

/**
 * @brief Overloading of the stream extraction operator for VectorInt class.
 * @note This operator should remove any previously information contained in the
 * provided VectorInt @p vector.
 * @note This operator throws an exception in some error cases (see below). 
 * Before throwing the corresponding exception, this operator clears
 * the provided object (it calls to clear() method) to leave it in a 
 * consistent state.
 * @throw std::out_of_range Throws a std::out_of_range exception if the number 
 * of elements read from the file is negative.
 * @param is The input stream to be used. Input/output parameter
 * @param vector The VectorInt object to be filled. Input/output parameter
 * @return A reference to the input stream
 */
std::istream &operator>>(std::istream &is, VectorInt &vector);

#endif /* VECTORINT_H */

